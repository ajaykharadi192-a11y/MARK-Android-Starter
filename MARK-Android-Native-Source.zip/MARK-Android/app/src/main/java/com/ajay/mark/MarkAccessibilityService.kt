package com.ajay.mark

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class MarkAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onServiceConnected() {
        instance = this
        super.onServiceConnected()
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile var instance: MarkAccessibilityService? = null
            private set
    }
}
