package com.ajay.mark

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var output: TextView
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val audioPermissionRequest = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        val title = TextView(this).apply {
            text = "MARK Assistant"
            textSize = 28f
            setTextColor(0xFF14213D.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "नमस्ते Ajay! नीचे बटन दबाकर बोलो।"
            textSize = 16f
            setPadding(0, 18, 0, 12)
        }
        output = TextView(this).apply {
            text = "कमांड का जवाब यहाँ दिखेगा।\n\nउदाहरण:\n• Chrome खोलो\n• YouTube खोलो\n• वॉल्यूम बढ़ाओ\n• Back दबाओ\n• Home पर जाओ\n• Google पर मौसम खोजो"
            textSize = 17f
            setTextColor(0xFF202124.toInt())
            setPadding(16, 16, 16, 16)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        val scroll = ScrollView(this)
        scroll.addView(output)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(makeButton("🎙️ बोलकर कमांड दो") { listen() })
        root.addView(makeButton("Accessibility सेटिंग खोलो (Back/Home के लिए)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(makeButton("ऑनलाइन AI / Google Search") {
            val query = output.text.toString().substringAfter("कमांड:", "").trim()
            openSearch(if (query.isBlank()) "AI assistant" else query)
        })
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = 8
        }
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("इस फोन में Speech Recognition उपलब्ध नहीं है।")
            return
        }
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
                sr.setRecognitionListener(object : android.speech.RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { status.text = "सुन रहा हूँ… बोलिए।" }
                    override fun onBeginningOfSpeech() { }
                    override fun onRmsChanged(rmsdB: Float) { }
                    override fun onBufferReceived(buffer: ByteArray?) { }
                    override fun onEndOfSpeech() { status.text = "आवाज़ समझ रहा हूँ…" }
                    override fun onError(error: Int) { status.text = "आवाज़ नहीं समझ आई। फिर कोशिश करें।" }
                    override fun onResults(results: Bundle?) {
                        val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        output.text = "कमांड: $words"
                        handleCommand(words)
                    }
                    override fun onPartialResults(partialResults: Bundle?) { }
                    override fun onEvent(eventType: Int, params: Bundle?) { }
                })
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "MARK को कमांड दें")
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            say("माइक्रोफ़ोन शुरू नहीं हो पाया।")
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale.ROOT).trim()
        when {
            command.contains("chrome") || command.contains("क्रोम") -> launchPackage("com.android.chrome", "Chrome")
            command.contains("youtube") || command.contains("यूट्यूब") -> launchPackage("com.google.android.youtube", "YouTube")
            command.contains("whatsapp") || command.contains("व्हाट्सएप") -> launchPackage("com.whatsapp", "WhatsApp")
            command.contains("वॉल्यूम बढ़") || command.contains("volume up") || command.contains("आवाज़ बढ़") -> {
                val am = getSystemService(AUDIO_SERVICE) as AudioManager
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                say("वॉल्यूम बढ़ा दिया।")
            }
            command.contains("वॉल्यूम कम") || command.contains("volume down") || command.contains("आवाज़ कम") -> {
                val am = getSystemService(AUDIO_SERVICE) as AudioManager
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                say("वॉल्यूम कम कर दिया।")
            }
            command.contains("back") || command.contains("वापस") -> {
                val ok = MarkAccessibilityService.instance?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK) ?: false
                say(if (ok) "वापस जा रहा हूँ।" else "पहले Accessibility सेटिंग में MARK सेवा चालू करें।")
            }
            command.contains("home") || command.contains("होम") -> {
                val ok = MarkAccessibilityService.instance?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME) ?: false
                say(if (ok) "होम स्क्रीन खोल रहा हूँ।" else "पहले Accessibility सेटिंग में MARK सेवा चालू करें।")
            }
            command.contains("google") || command.contains("खोज") || command.contains("सर्च") || command.contains("मौसम") -> openSearch(command)
            command.contains("सेटिंग") || command.contains("settings") -> {
                startActivity(Intent(Settings.ACTION_SETTINGS)); say("सेटिंग खोल रहा हूँ।")
            }
            else -> say("यह कमांड अभी बेसिक संस्करण में नहीं है। ऑनलाइन जवाब के लिए Google Search बटन इस्तेमाल करें।")
        }
    }

    private fun launchPackage(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            startActivity(launch)
            say("$label खोल रहा हूँ।")
        } else {
            say("$label ऐप नहीं मिला।")
        }
    }

    private fun openSearch(query: String) {
        val url = "https://www.google.com/search?q=" + Uri.encode(query)
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: ActivityNotFoundException) { say("ब्राउज़र नहीं मिला।") }
    }

    private fun say(message: String) {
        status.text = message
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "mark-response")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.getDefault()
            }
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
