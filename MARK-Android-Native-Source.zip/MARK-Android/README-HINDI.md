# MARK Android (शुरुआती संस्करण)

यह पुराने PC/Laptop Python प्रोजेक्ट का Android-native starter है। यह पूरी तरह से मूल प्रोजेक्ट का automatic port नहीं है। इसमें Android के लिए शुरुआती voice-command app बनाया गया है।

## अभी उपलब्ध
- बटन दबाकर Hindi speech recognition शुरू करना (फोन की Speech Recognition सेवा पर निर्भर; EXTRA_PREFER_OFFLINE केवल प्राथमिकता है, offline की गारंटी नहीं)।
- Android Text-to-Speech से जवाब बोलना।
- Chrome, YouTube, WhatsApp खोलने का प्रयास।
- मीडिया वॉल्यूम ऊपर/नीचे करना।
- Google Search खोलना।
- Accessibility सेवा सक्षम होने पर Back और Home global actions।

## अभी उपलब्ध नहीं
- हमेशा बैकग्राउंड में “Hey MARK” wake word सुनना।
- Gemini/OpenAI API integration; यह जानबूझकर इस starter में शामिल नहीं है।
- सभी पुराने PC commands (Windows settings, desktop control, arbitrary file actions आदि)।
- हर फोन/Android संस्करण पर सभी commands की गारंटी।

## APK बनाने का आसान तरीका: GitHub Actions
1. GitHub में खाली repository बनाएँ।
2. इस ZIP को extract करें और अंदर की सभी files/folders repository root में upload करें। ZIP फ़ाइल खुद repository में upload न करें। `.github/workflows/build-apk.yml` भी शामिल होनी चाहिए।
3. Commit changes करें।
4. GitHub repository → Actions → Build MARK Android APK → Run workflow (या main branch में push पर workflow अपने-आप चलेगा)।
5. सफल run खोलें और Artifacts में `MARK-debug-APK` डाउनलोड करें।
6. ZIP extract करें; `app-debug.apk` को Android पर install करें। Install के समय Android अनुमति माँगे तो जाँचकर स्वीकार करें।

## Back/Home के लिए
ऐप में Accessibility सेटिंग खोलने वाला बटन दबाएँ और MARK Assistant सेवा को स्वयं चालू करें। यह अनुमति शक्तिशाली है; केवल तभी चालू करें जब आप ऐप के कोड और व्यवहार से सहमत हों।

## सुरक्षा
किसी भी API key/password को source code या public repository में न रखें। यह debug build है, Play Store release नहीं।
